import React from 'react';
import Navigator from './frontend/navigator'; // 경로는 위치에 따라 조정

const App = () => {
  return <Navigator />;
};

export default App;