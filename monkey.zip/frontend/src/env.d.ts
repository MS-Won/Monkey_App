declare module '@env' {
  export const OPENAI_API_KEY: string;
}
