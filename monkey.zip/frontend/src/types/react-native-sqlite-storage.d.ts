// src/types/react-native-sqlite-storage.d.ts
declare module 'react-native-sqlite-storage' {
    const SQLite: any;
    export default SQLite;
  }
  